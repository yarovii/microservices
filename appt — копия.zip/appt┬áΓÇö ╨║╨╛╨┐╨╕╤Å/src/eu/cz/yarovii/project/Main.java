package eu.cz.yarovii.project;

public class Main {
    public static void main(String[] args) {
//        new Window("Application", 960, 640, new Application());
        new Application();
    }
}
