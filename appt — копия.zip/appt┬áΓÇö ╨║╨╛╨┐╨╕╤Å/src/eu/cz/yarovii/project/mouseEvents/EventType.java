package eu.cz.yarovii.project.mouseEvents;

public enum EventType {
    MOUSE_PRESSED,
    MOUSE_RELEASED,
    MOUSE_MOVED
}
