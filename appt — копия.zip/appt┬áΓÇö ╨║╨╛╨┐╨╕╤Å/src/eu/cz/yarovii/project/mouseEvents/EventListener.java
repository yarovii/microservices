package eu.cz.yarovii.project.mouseEvents;

import eu.cz.yarovii.project.mouseEvents.type.MouseButton;

public interface EventListener {
    public void onEvent(MouseButton mp);
}
